#if 0
#include <stdio.h>

int main()
{
	int num = 10;

	if (num < 5)
	{
		printf("num < 5\n");
	}
	printf("num is %d\n", num);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	int num = 1;

	if (num < 5);
	{
		printf("num < 5\n");
	}
	printf("num is %d\n", num);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	int num = 8;

	if (num < 5) printf("Hello\n"); printf("Hello\n");
	{
		printf("num < 5\n");
	}
	printf("num is %d\n", num);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 2;

		if (num < 5) 
				printf("num < 5\n");
		printf("num is %d\n", num);

		printf("Hello World\n");	
		return 0;
}
#endif

#if 0
#include <stdio.h>

int main()
{
		if (-3) 
				printf("Hello World\n");	
		return 0;
}
#endif














