#if 0
#include <stdio.h>

int main()
{
	int num_array[5] = {1, 2, 3, 4, 5};
	int index;

	index = 0;
	do
	{
		printf("Index %d has Element %d\n", index, num_array[index]);
		index++;
	} while (index < 5);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	int num_array[5] = {11, 222, 3333, 44444, 555555};
	int index;

	index = 0;
	do
	{
		printf("Index %d has Element %d\n", index, num_array[index]);
		index++;
	} while (index < 5);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	int num_array[5];
	int index;

	index = 0;
	do
	{
		printf("Index %d has Element %d\n", index, num_array[index]);
		index++;
	} while (index < 5);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	int num_array[5] = { 0 };
	int index;

	index = 0;
	do
	{
		printf("Index %d has Element %d\n", index, num_array[index]);
		index++;
	} while (index < 5);

	return 0;
}
#endif

#if 0
#include <stdio.h>

int main()
{
	int num_array[5] = { 10, 20 };
	int index;

	index = 0;
	do
	{
		printf("Index %d has Element %d\n", index, num_array[index]);
		index++;
	} while (index < 5);

	return 0;
}
#endif

#if 0
#include <stdio.h>

int main()
{
		int size = 5;
		int num_array[size] = {10, 20, 30, 40, 50};
		int index;

		index = 0;
		do
		{
				printf("Index %d has Element %d\n", index, num_array[index]);
				index++;
		} while (index < 5);

		return 0;
}
#endif

#if 1
#include <stdio.h>

int main()
{
		int size = 5;
		int num_array[size];
		int index;

		index = 0;
		do
		{
				printf("Index %d has Element %d\n", index, num_array[index]);
				index++;
		} while (index < 5);

		return 0;
}
#endif









