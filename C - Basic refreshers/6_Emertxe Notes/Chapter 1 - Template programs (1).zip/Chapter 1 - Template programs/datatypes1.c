#if 0
#include <stdio.h>

int main()
{
	char option;
	int age;
	float height;

	scanf("%c", &option);
	printf("The character is %c\n", option);
	scanf("%d", &age);
	printf("The integer is %d\n", age);
	scanf("%f", &height);
	printf("The float is %f\n", height);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	char option;
	scanf("%c", &option);
	printf("The values are %c %d \n", option, option);

	return 0;
}
#endif

#if 0
#include <stdio.h>

int main()
{
	char option;
	int age;
	float height;

	scanf("%d", &age);
	printf("The integer is %d\n", age);
	//getchar();
	scanf(" %c", &option);
	printf("The character is %c\n", option);
	scanf("%f", &height);
	printf("The float is %f\n", height);

	return 0;
}
#endif

#if 0
#include <stdio.h>

int main()
{
	char option;
	scanf("%d", &option);
	printf("The values are %c %d \n", option, option);

	return 0;
}
#endif

#if 1
#include <stdio.h>

int main()
{
	int option;
	scanf("%d", &option);
	printf("The values are %c %d \n", option, option);

	return 0;
}
#endif
















