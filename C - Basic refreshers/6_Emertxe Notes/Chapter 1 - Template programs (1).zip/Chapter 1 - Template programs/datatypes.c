#if 1
#include <stdio.h>

int main()
{
	char option;
	int age;
	float height;

	printf("The character is %c\n", option);
	printf("The integer is %d\n", age);
	printf("The float is %f\n", height);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	char option = 'A';
	int age = 25;
	float height = 6.1;

	printf("The character is %c, equvqlent decimal val = %d\n", option, option);
	printf("The integer is %d\n", age);
	printf("The float is %f\n", height);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	char option = 'A';
	//char option = 65;
	//char option = 0x41;
	//char option = 0101;
	//char option = 101;

	printf("The character is %c %d %o %x\n", option, option, option, option);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	float option = 6.5;
	//float option = 6.0;

	printf("option = %f\n", option);
	printf("option = %g\n", option);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	int option = 0x1abc;

	printf("option = %x\n", option);
	printf("option = %X\n", option);

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	int option = 0x1ABC;

	printf("option = %x\n", option);
	printf("option = %X\n", option);

	return 0;
}
#endif
