#if 0
#include <stdio.h>

int main()
{
	int num;

	num = 7 - 4 * 3 / 2 + 5;

	printf("Result is %d\n", num);

	return 0;
}
#endif
#if 1
#include <stdio.h>

int main()
{
	int num;

	//num = 5 + 10 * 15 / 3 - 2;
	num = (10 + 15) / 3 * 9 - 3;

	printf("Result is %d\n", num);

	return 0;
}
#endif










