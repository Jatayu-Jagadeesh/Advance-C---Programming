#if 0
#include <stdio.h>

int main()
{
	int num = 3;

	if (num < 5)
	{
		printf("num is smaller than 5\n");
	}
	else if (num > 5)
	{
		printf("num is greater than 5\n");
	}
	else
	{
		printf("num is equal to 5\n");
	}

	return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 5;

		if (num < 5);
		{
				printf("num is smaller than 5\n");
		}
		else if (num > 5)
		{
				printf("num is greater than 5\n");
		}
		else
		{
				printf("Hello world\n");
		}
		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 5;

		if (num < 5)
				printf("num is smaller than 5\n");
		printf("num is smaller than 5\n");
		else if (num > 5)
		{
				printf("num is greater than 5\n");
		}
		else
		{
				printf("Hello world\n");
		}
		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 3;

		if (num < 5)
				printf("1. num is smaller than 5\n");
		printf("2. num is smaller than 5\n");
		if (num > 5)
		{
				printf("num is greater than 5\n");
		}
		else
		{
				printf("Hello world\n");
		}
		return 0;
}
#endif

#if 0
#include <stdio.h>

int main()
{
		int num = 2;

		if (num < 5)
				printf("num is smaller than 5\n");
		if (num > 5)
		{
				printf("num is greater than 5\n");
		}
		else
		{
				printf("Hello world\n");
		}
		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 6;

		if (num < 5)
				printf("num is smaller than 5\n");
		if (num > 5)
		{
				printf("num is greater than 5\n");
		}
		else
		{
				printf("Hello world\n");
		}
		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 40;

		if (num > 10)
				printf("num is greater than 10\n");
		else if (num > 20)
				printf("num is greater than 20\n");
		else if (num > 30)
				printf("num is greater than 30\n");
		else if (num > 40)
				printf("num is greater than 40\n");
		else
		{
				printf("Hello world\n");
		}
		return 0;
}
#endif
#if 1
#include <stdio.h>

int main()
{
		int num = 40;

		if (num > 10)
				printf("num is greater than 10\n");
		if (num > 20)
				printf("num is greater than 20\n");
		if (num > 30)
				printf("num is greater than 30\n");
		if (num > 40)
				printf("num is greater than 40\n");
		else
		{
				printf("Hello world\n");
		}
		return 0;
}
#endif

#if 0
#include <stdio.h>

int main()
{
		int num = 50;

		if (num > 10)
				printf("num is greater than 10\n");
		else if (num > 20)
				printf("num is greater than 20\n");
		else if (num > 30)
				printf("num is greater than 30\n");
		else if (num > 40)
				printf("num is greater than 40\n");
		else
		{
				printf("Hello world\n");
		}
		return 0;
}
#endif








