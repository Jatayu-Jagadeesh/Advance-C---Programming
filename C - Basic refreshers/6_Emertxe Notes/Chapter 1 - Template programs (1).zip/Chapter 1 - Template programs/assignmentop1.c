#if 0
#include <stdio.h>

int main()
{
		float num1 = 0;

		if (num1 = 1)
		{
				printf("Yes, it is equal!!\n");
		}
		else
		{
				printf("No, it is not equal\n");
		}

		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 0;

		if ( num = 1)
		{
				printf("Yes, it is equal!!\n");
		}
		else
		{
				printf("No, it is not equal\n");
		}

		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 0;

		if ( num = 0)
		{
				printf("Yes, it is equal!!\n");
		}
		else
		{
				printf("No, it is not equal\n");
		}

		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 0;

		if ( num == 0)
		{
				printf("Yes, it is equal!!\n");
		}
		else
		{
				printf("No, it is not equal\n");
		}

		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 0;

		if ( num == 3)
		{
				printf("Yes, it is equal!!\n");
		}
		else
		{
				printf("No, it is not equal\n");
		}

		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 0;

		if ( 0 == num)
		{
				printf("Yes, it is equal!!\n");
		}
		else
		{
				printf("No, it is not equal\n");
		}

		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 0;

		if ( 2 == num)
		{
				printf("Yes, it is equal!!\n");
		}
		else
		{
				printf("No, it is not equal\n");
		}

		return 0;
}
#endif
#if 0
#include <stdio.h>

int main()
{
		int num = 0;

		if ( 2 = num) 
		{
				printf("Yes, it is equal!!\n");
		}
		else
		{
				printf("No, it is not equal\n");
		}

		return 0;
}
#endif
