#if 1
#include <stdio.h>

int main()
{
		
		
	float num1 = 0.7;
	printf("%.10f %.10f\n", num1, 0.7);

	if (num1 == 0.7f)
	{
		printf("Yes, it is equal\n");
	}
	else
	{
		printf("No, it is not equal\n");
	}

	return 0;
}
#endif

#if 0 
#include <stdio.h>

int main()
{
		
		
	float num1 = 0.5;
	printf("%.10f %.10f\n", num1, 0.5);

	if (num1 == 0.5)
	{
		printf("Yes, it is equal\n");
	}
	else
	{
		printf("No, it is not equal\n");
	}

	return 0;
}
#endif
