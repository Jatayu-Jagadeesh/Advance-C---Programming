#if 1
#include <stdio.h>

int add_numbers(int num1, int num2);
int main()
{
	int num1 = 10, num2 = 20;
	int sum = 0;

	sum = add_numbers(num1, num2);
	printf("Sum is %d\n", sum);

	return 0;
}

int add_numbers(int num1, int num2)
{
	int sum = 0;

	sum = num1 + num2;

	return sum;
}
#endif
#if 0
#include <stdio.h>

int add_numbers(int , int );
int main()
{
	int sum = 0;

	sum = add_numbers(100, 200);
	printf("Sum is %d\n", sum);

	return 0;
}

int add_numbers(int num1, int num2)
{
	int sum = 0;

	sum = num1 + num2;

	return sum;
}
#endif
#if 0
#include <stdio.h>

int add_numbers(int , int );
int main()
{
	int num1 = 10, num2 = 20;
	int sum = 0;

	sum = add_numbers(num1 , num2);
	printf("Sum is %d\n", sum);

	return 0;
}

int add_numbers(int x, int y)
{
	int s = 0;
	s = x + y;
	return s;
}
#endif
#if 0
#include <stdio.h>

int add_numbers(int , int );
int main()
{
	int num1 = 10, num2 = 20;
	int sum = 0;

	sum = add_numbers(num1, 200);
	printf("Sum is %d\n", sum);

	return 0;
}

int add_numbers(int x, int y)
{
	int s = 0;
	s = x + y;
	return s;
}
#endif
#if 0
#include <stdio.h>

float add_numbers(int , int );
int main()
{
	int num1 = 10, num2 = 20;
	float sum = 0;

	sum = add_numbers(num1, num2);
	printf("avg is %f\n", sum);

	return 0;
}

float add_numbers(int x, int y)
{
	int s = 0;
	s = x + y;
	return s / 2;
}
#endif
#if 0
#include <stdio.h>

float add_numbers(int , int );
int main()
{
	int num1 = 5, num2 = 20;
	float sum = 0;

	sum = add_numbers(num1, num2);
	printf("avg is %f\n", sum);

	return 0;
}

float add_numbers(int x, int y)
{
	int s = 0;
	s = x + y;
	return s / 2;
}
#endif
#if 0
#include <stdio.h>

float add_numbers(int , int );
int main()
{
	int num1 = 5, num2 = 20;
	float sum = 0;

	sum = add_numbers(num1, num2);
	printf("avg is %f\n", sum);

	return 0;
}

float add_numbers(int x, int y)
{
	int s = 0;
	s = x + y;
	return (float)s / 2;
	//return s / 2.0;
}
#endif
#if 0
#include <stdio.h>
//float add_numbers(int, int);
int main()
{
	int num1 = 5, num2 = 20;
	float sum = 0;

	sum = add_numbers(num1, num2);
	printf("avg is %f\n", sum);

	return 0;
}

float add_numbers(int x, int y)
{
	int s = 0;
	s = x + y;
	return (float)s / 2;
}
#endif
#if 0
#include <stdio.h>

int main()
{
	int num1 = 5, num2 = 20;
	float sum = 0;

	sum = add_numbers(num1, num2);
	printf("avg is %f\n", sum);

	return 0;
}

int add_numbers(int x, int y)
{
	int s = 0;
	s = x + y;
	return s / 2;
}
#endif
