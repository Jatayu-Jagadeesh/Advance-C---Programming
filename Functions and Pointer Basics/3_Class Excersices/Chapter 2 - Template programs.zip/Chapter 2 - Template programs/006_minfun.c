#include <stdio.h>

int main()
{
	dummy(20);		

	return 0;
}

/* minimum valid function */
dummy()
{

}
